﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace Xamarin_Suma
{
    public partial class MainPage : ContentPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        // Button Click Event Handler
        void OnButtonClicked(object sender, EventArgs args)
        {           
            var A = int.Parse(this.EntryA.Text);
            var B = int.Parse(this.EntryB.Text);
            var C = A + B;
            this.EntryC.Text = C.ToString();
        }
    }
}
