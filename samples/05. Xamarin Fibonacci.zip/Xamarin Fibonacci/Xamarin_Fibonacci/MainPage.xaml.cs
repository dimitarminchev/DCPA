﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace Xamarin_Fibonacci
{
    public partial class MainPage : ContentPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        // Button Click Event Handler
        void OnButtonClicked(object sender, EventArgs args)
        {
            List<int> fib = new List<int>();
            fib.Add(1);
            fib.Add(1);                       
            int limit = int.Parse(this.EntryLimit.Text);
            int a = 1, b = 1, c = a + b;
            while (c < limit)
            {
                fib.Add(c);
                a = b;
                b = c;
                c = a + b;
            }
            this.ListViewNumbers.ItemsSource = fib;
        }
    }
}
