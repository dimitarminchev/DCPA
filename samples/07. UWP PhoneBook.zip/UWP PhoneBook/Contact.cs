﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UWP_PhoneBook
{
    // Model
    public class Contact
    {
        public Uri picture { get; set;  }
        public String name { get; set; }
        public String phone { get; set; }
        // Constructor
        public Contact(Uri _picture, String _name, String _phone)
        {
            this.picture = _picture;
            this.name = _name;
            this.phone = _phone;
        }
    }
}
