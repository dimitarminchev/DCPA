﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace UWP_ClickerMania
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        // var
        private int counter = 0;
        private StorageFile file;
        private StorageFolder local = ApplicationData.Current.LocalFolder;

        // Constructor
        public MainPage()
        {
            this.InitializeComponent();
            Read();
        }

        // Button Even Handler
        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            counter++;
            Click.Text = counter.ToString();
            // Save to file
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(Click.Text.ToCharArray());
            var _file = await local.CreateFileAsync("clicker.txt", CreationCollisionOption.ReplaceExisting);
            using (var _stream = await _file.OpenStreamForWriteAsync())  _stream.Write(bytes, 0, bytes.Length);            
        }

        // Read from File
        private async void Read()
        {            
            try
            {
                file = await local.GetFileAsync("clicker.txt");
                if (file == null) file = await local.CreateFileAsync("clicker.txt");
                else 
                {
                    Stream stream = await file.OpenStreamForReadAsync();
                    StreamReader reader = new StreamReader(stream);
                    Click.Text = reader.ReadToEnd();
                    if (Click.Text == "")
                    {
                        Click.Text = "0";
                        counter = 0;
                    }
                    else counter = int.Parse(Click.Text);
                }               
            }
            catch { ;; }            
        }
    }
}
