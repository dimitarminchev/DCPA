﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace Xamarin_ClickerMania
{
    public partial class MainPage : ContentPage
    {
       
        // Constructor
        public MainPage()
        {
            this.InitializeComponent();
            // Timer
            Device.StartTimer(TimeSpan.FromSeconds(1), callback);           
        }

        // Timer Event Handler
        private bool callback()
        {
            int T = int.Parse(this.Timer.Text);
            this.Timer.Text = (++T).ToString();
            // clicks Per Minute
            this.CPM.Text = (float.Parse(this.Clicks.Text) / 
                 float.Parse(this.Timer.Text) * 60).ToString("N2");
            return true;
        }

        // Button Event Handler
        void OnButtonClicked(object sender, EventArgs args)
        {
            int N = int.Parse(this.Clicks.Text);
            this.Clicks.Text = (++N).ToString();
        }
    }
}
