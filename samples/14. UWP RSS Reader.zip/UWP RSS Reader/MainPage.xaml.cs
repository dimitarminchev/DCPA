﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Web.Syndication;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace UWP_RSS_Reader
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        // View Model
        private ObservableCollection<FeedItem> RSSFeed = new ObservableCollection<FeedItem>();

        // Constructor
        public MainPage()
        {
            this.InitializeComponent();
            RSSItems.ItemsSource = RSSFeed;
            RSSLoad();
        }

        // RSS
        private async void RSSLoad()
        {
            Uri link = new Uri("http://www.minchev.eu/rss/");
            SyndicationClient client = new SyndicationClient();
            SyndicationFeed feed = await client.RetrieveFeedAsync(link);
            if (feed != null)
            {
                foreach (SyndicationItem Node in feed.Items)
                {
                    var Item = new FeedItem
                    {
                        Title = Node.Title.Text,
                        Link = Node.Id,
                        PublishedDate = Node.PublishedDate.ToString()
                    };
                    RSSFeed.Add(Item);
                }
            }

        }

    }
}
