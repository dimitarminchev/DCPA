﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace Suma_2._0
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        void OnButtonClicked(object sender, EventArgs args)
        {
            var A = int.Parse(EntryA.Text);
            var B = int.Parse(EntryB.Text);
            var C = A + B;
            EntryC.Text = C.ToString();
        }

    }
}
