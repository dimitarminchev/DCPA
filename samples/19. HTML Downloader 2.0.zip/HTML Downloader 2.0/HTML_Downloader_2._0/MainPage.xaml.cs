﻿using AngleSharp.Parser.Html;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HTML_Downloader_2._0
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        // Button Click Event Handler
        private async void OnButtonClicked(object sender, EventArgs args)
        {
            // Get Html
            string html = await Go(new Uri(URL.Text));

            // Angle Sharp Parsing
            var temp = new HtmlParser().Parse(html);
            string text = temp.Body.TextContent;

            // Plain Text
            HTML.Text = text;
        }

        // Get the HTML
        private async Task<string> Go(Uri link)
        {
            HttpClient client = new HttpClient();
            return await client.GetStringAsync(link);
        }

    }
}
