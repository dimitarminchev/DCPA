﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace RSS_Reader_2._0
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        void OnButtonClicked(object sender, EventArgs args)
        {
            var link = this.EntryURL.Text;
            var posts = new FeedReader().ReadFeed(link);
            ListRSS.ItemsSource = new ObservableCollection<FeedItem>(posts);
        }

    }
}
