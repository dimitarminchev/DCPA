﻿using System;
using System.IO;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace Clicker_Mania_1._0
{
    /// <summary>
    /// Clicker Mania 1.0
    /// </summary>
    public sealed partial class MainPage : Page
    {
        // var
        private int counter = 0;
        private StorageFile file;
        private StorageFolder local = ApplicationData.Current.LocalFolder;

        // Constructor
        public MainPage()
        {
            this.InitializeComponent();
            Read();
        }

        // Button Even Handler
        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            counter++;
            Click.Text = counter.ToString();
            // Save to file
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(Click.Text.ToCharArray());
            var _file = await local.CreateFileAsync("clicker.txt", CreationCollisionOption.ReplaceExisting);
            using (var _stream = await _file.OpenStreamForWriteAsync()) _stream.Write(bytes, 0, bytes.Length);
        }

        // Read from File
        private async void Read()
        {
            try
            {
                file = await local.GetFileAsync("clicker.txt");
                if (file == null) file = await local.CreateFileAsync("clicker.txt");
                else
                {
                    Stream stream = await file.OpenStreamForReadAsync();
                    StreamReader reader = new StreamReader(stream);
                    Click.Text = reader.ReadToEnd();
                    if (Click.Text == "")
                    {
                        Click.Text = "0";
                        counter = 0;
                    }
                    else counter = int.Parse(Click.Text);
                }
            }
            catch {; ; }
        }
    }
}