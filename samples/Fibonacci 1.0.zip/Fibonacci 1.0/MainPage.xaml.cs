﻿using System.Collections.ObjectModel;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace Fibonacci_1._0
{
    /// <summary>
    /// Fibonacci 1.0
    /// </summary>
    public sealed partial class MainPage : Page
    {
        // Data Model
        private ObservableCollection<int> fib = new ObservableCollection<int>();

        // Constructor
        public MainPage()
        {
            this.InitializeComponent();
            ListBoxFib.ItemsSource = fib;
        }

        // Button Event Handler
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            fib.Add(1);
            fib.Add(1);
            int limit = int.Parse(TextBoxLimit.Text);
            int a = 1, b = 1, c = a + b;
            while (c < limit)
            {
                fib.Add(c);
                a = b;
                b = c;
                c = a + b;
            }
        }
    }
}