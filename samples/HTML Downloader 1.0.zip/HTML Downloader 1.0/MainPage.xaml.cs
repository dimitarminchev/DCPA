﻿using AngleSharp.Parser.Html;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace HTML_Downloader_1._0
{
    /// <summary>
    /// HTML Downloader 1.0
    /// </summary>
    public sealed partial class MainPage : Page
    {
        // Constructor
        public MainPage()
        {
            this.InitializeComponent();
        }

        // Button Click Event Handler
        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            string html = await Go(new Uri(URL.Text));
            var temp = new HtmlParser().Parse(html);
            string text = temp.Body.TextContent;
            HTML.Text = text;
        }

        // Get the HTML
        private async Task<string> Go(Uri link)
        {
            HttpClient client = new HttpClient();
            return await client.GetStringAsync(link);
        }
    }
}
