﻿using System;
using System.Threading.Tasks;
using Xamarin.Forms;
using AngleSharp.Parser.Html;
using System.Net.Http;

namespace HTML_Downloader_2._0
{
    /// <summary>
    /// HTML Downloader 2.0
    /// </summary>
    public partial class MainPage : ContentPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        // Button Click Event Handler
        private async void OnButtonClicked(object sender, EventArgs args)
        {
            // Get Html
            string html = await Go(new Uri(this.URL.Text));

            // Angle Sharp Parsing
            var temp = new HtmlParser().Parse(html);
            string text = temp.Body.TextContent;

            // Plain Text
            this.HTML.Text = text;
        }

        // Get the HTML
        private async Task<string> Go(Uri link)
        {
            HttpClient client = new HttpClient();
            return await client.GetStringAsync(link);
        }
    }
}
