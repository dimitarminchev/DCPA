﻿using System;
using System.Net.Http;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Newtonsoft.Json;
using Windows.Media.SpeechSynthesis;

namespace JSON_Reader_1._0
{
    /// <summary>
    /// JSON Reader 1.0
    /// </summary>
    public sealed partial class MainPage : Page
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public MainPage()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// New Joke Button Click Event Handler
        /// </summary>
        private async void NewJokeButtonClickEventHandler(object sender, RoutedEventArgs e)
        {
            // 1. Http Client
            HttpClient client = new HttpClient();

            // 2. Http Request to Receive JSON Response
            string json = await client.GetStringAsync(new Uri("https://api.chucknorris.io/jokes/random"));

            // 3. Deserialize JSON to Object
            Joke joke = JsonConvert.DeserializeObject<Joke>(json);

            // 4. Show the Joke in the UI
            JOKE.Text = joke.value;
        }

        /// <summary>
        /// Tell Joke Button Click Event Handler
        /// </summary>
        private async void TellJokeButtonClickEventHandler(object sender, RoutedEventArgs e)
        { 
            if (JOKE.Text != "")
            {
                // 1. The media object for controlling and playing audio
                MediaElement media = new MediaElement();

                // 2. Speech synthesis engine
                SpeechSynthesizer synth = new SpeechSynthesizer();

                // 3. Generate the audio stream from plain text
                SpeechSynthesisStream stream = await synth.SynthesizeTextToStreamAsync(JOKE.Text);

                // 4. Send the stream to the media object
                media.SetSource(stream, stream.ContentType);
                media.Play();
            }
        }
    }
}
