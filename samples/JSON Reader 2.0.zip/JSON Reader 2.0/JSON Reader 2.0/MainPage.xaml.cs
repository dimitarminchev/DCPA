﻿using AngleSharp.Parser.Html;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using Xamarin.Forms;

namespace JSON_Reader_2._0
{
    /// <summary>
    /// JSON Reader 2.0
    /// </summary>
    public partial class MainPage : ContentPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        // Button Event Handler
        async void OnButtonClicked(object sender, EventArgs args)
        {
            // Download JSON
            HttpClient client = new HttpClient();
            var json = await client.GetStringAsync(new Uri("https://api.chucknorris.io/jokes/random"));

            // Deserialize the JSON
            var joke = JsonConvert.DeserializeObject<RootObject>(json);

            // Parse the HTML
            var html = new HtmlParser().Parse(joke.value);
            var text = html.Body.TextContent;

            // Tell the Joke
            this.Joke.Text = text;
        }
    }
}
