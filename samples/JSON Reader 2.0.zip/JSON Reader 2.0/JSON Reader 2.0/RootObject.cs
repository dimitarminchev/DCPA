﻿namespace JSON_Reader_2._0
{
    // https://api.chucknorris.io/jokes/random
    // http://json2csharp.com/
    public class RootObject
    {
        public object category { get; set; }
        public string icon_url { get; set; }
        public string id { get; set; }
        public string url { get; set; }
        public string value { get; set; }
    }
}
