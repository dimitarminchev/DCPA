﻿using System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace Phone_Book_1._0
{
    /// <summary>
    /// Phone Book 1.0
    /// </summary>
    public sealed partial class AddPage : Page
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public AddPage()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Button Click Event Handler
        /// </summary>
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var picture = new Uri(boxPicture.Text);
            var contact = new Contact(picture, boxName.Text, boxPhone.Text);
            this.Frame.Navigate(typeof(MainPage), contact);
        }
    }
}
