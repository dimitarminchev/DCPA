﻿using System;
using Xamarin.Forms;
using Phone_Book_2._0.Model;

namespace Phone_Book_2._0
{
    public partial class AddPage : ContentPage
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public AddPage()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Button Click Event Handler
        /// </summary>
        private async void Button_Clicked(object sender, System.EventArgs e)
        {
            var contact = new Contact
            (
                picture: new Uri(this.Picture.Text),
                name: this.Name.Text,
                phone: this.Phone.Text
            );

            await Navigation.PushAsync(new MainPage(contact));
        }
    }
}
