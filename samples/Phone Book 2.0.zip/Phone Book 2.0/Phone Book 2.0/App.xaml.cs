﻿using Xamarin.Forms;

namespace Phone_Book_2._0
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            MainPage = new NavigationPage(new MainPage());
        }

        protected override void OnStart()
        {
            // nope
        }

        protected override void OnSleep()
        {
            // nope
        }

        protected override void OnResume()
        {
            // nope
        }
    }
}
