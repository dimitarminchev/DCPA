﻿using Phone_Book_2._0.Model;
using Xamarin.Forms;

namespace Phone_Book_2._0
{
    public partial class MainPage : ContentPage
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public MainPage(Contact contact = null)
        {
            InitializeComponent();

            this.ListView.ItemsSource = ViewModel.Contacts;

            if (contact is Contact)
            {
                ViewModel.Contacts.Add(contact);
            }
        }

        /// <summary>
        /// Button Click Event Handler
        /// </summary>
        private async void Button_Clicked(object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new AddPage());
        }
    }
}
