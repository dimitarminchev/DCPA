﻿namespace RSS_Reader_1._0
{
    // RSS Feed Item
    public class FeedItem
    {
        public string Title { get; set; }
        public string Link { get; set; }
        public string PublishedDate { get; set; }
    }
}