﻿using System;
using System.Collections.ObjectModel;
using Windows.UI.Xaml.Controls;
using Windows.Web.Syndication;

namespace RSS_Reader_1._0
{
    /// <summary>
    /// RSS Reader 1.0
    /// </summary>
    public sealed partial class MainPage : Page
    {
        // View Model
        private ObservableCollection<FeedItem> RSSFeed = new ObservableCollection<FeedItem>();

        // Constructor
        public MainPage()
        {
            this.InitializeComponent();
            // RSS
            RSSItems.ItemsSource = RSSFeed;
            RSSLoad();
        }

        // RSS
        private async void RSSLoad()
        {
            var link = new Uri("http://www.minchev.eu/rss/");
            var client = new SyndicationClient();
            var feed = await client.RetrieveFeedAsync(link);
            if (feed != null)
            {
                foreach (var Node in feed.Items)
                {
                    var Item = new FeedItem
                    {
                        Title = Node.Title.Text,
                        Link = Node.Id,
                        PublishedDate = Node.PublishedDate.ToString()
                    };
                    RSSFeed.Add(Item);
                }
            }

        }
    }
}