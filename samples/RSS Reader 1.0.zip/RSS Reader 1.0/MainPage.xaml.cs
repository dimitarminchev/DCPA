﻿using System;
using System.Collections.ObjectModel;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.Web.Syndication;

namespace RSS_Reader_1._0
{
    /// <summary>
    /// RSS Reader 1.0
    /// </summary>
    public sealed partial class MainPage : Page
    {
        /// <summary>
        /// View Model
        /// </summary>
        private ObservableCollection<Item> Items = new ObservableCollection<Item>();

        /// <summary>
        /// Constructor
        /// </summary>
        public MainPage()
        {
            this.InitializeComponent();
            RSS.ItemsSource = Items;
        }

        /// <summary>
        /// Button Click Event Handler
        /// </summary>
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Download();
        }

        /// <summary>
        /// Download Handler
        /// </summary>
        private async void Download()
        {
            var uri = new Uri(URI.Text);
            var client = new SyndicationClient();
            var feed = await client.RetrieveFeedAsync(uri);
            if (feed != null)
            {
                foreach (var node in feed.Items)
                {
                    Items.Add(new Item
                    {
                        Title = node.Title.Text,
                        Link = node.Id,
                        PublishedDate = node.PublishedDate.ToString()
                    });
                }
            }
        }
    }
}
