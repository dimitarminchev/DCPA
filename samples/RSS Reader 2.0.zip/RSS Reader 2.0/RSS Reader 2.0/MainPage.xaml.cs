﻿using System;
using System.Collections.ObjectModel;
using Xamarin.Forms;

namespace RSS_Reader_2._0
{
    /// <summary>
    /// Business Loginc (BL): RSS Reader 2.0
    /// </summary>
    public partial class MainPage : ContentPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        // Button Click Event Handler
        private void Button_Clicked(object sender, EventArgs e)
        {
            var link = this.URI.Text;
            var posts = new FeedReader().ReadFeed(link);
            this.RSS.ItemsSource = new ObservableCollection<FeedItem>(posts);
        }
    }
}
