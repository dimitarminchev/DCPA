﻿using System;
using System.Collections.ObjectModel;
using Xamarin.Forms;

namespace RSS_Reader_2._0
{
    /// <summary>
    /// RSS Reader 2.0
    /// </summary>
    public partial class MainPage : ContentPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        // Button Event Handler
        void OnButtonClicked(object sender, EventArgs args)
        {
            var link = this.EntryURL.Text;
            var posts = new FeedReader().ReadFeed(link);
            this.ListRSS.ItemsSource = new ObservableCollection<FeedItem>(posts);
        }
    }
}
