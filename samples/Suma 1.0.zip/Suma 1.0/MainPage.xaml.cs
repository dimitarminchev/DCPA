﻿using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace Suma_1._0
{
    /// <summary>
    /// Business Logic (BL): Suma 1.0
    /// </summary>
    public sealed partial class MainPage : Page
    {
        // Constructor
        public MainPage()
        {
            this.InitializeComponent();
        }

        // Button Click Event Handler
        private void OnButtonClicked(object sender, RoutedEventArgs e)
        {
            var A = int.Parse(this.boxA.Text);
            var B = int.Parse(this.boxB.Text);
            var C = A + B;
            this.boxAB.Text = C.ToString();
        }
    }
}
