﻿using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace Suma_1._0
{
    /// <summary>
    /// Suma 1.0
    /// </summary>
    public sealed partial class MainPage : Page
    {
        // Constructor
        public MainPage()
        {
            this.InitializeComponent();
        }

        // Button Click Event Handler
        private void OnButtonClicked(object sender, RoutedEventArgs e)
        {
            var A = int.Parse(this.TextBoxA.Text);
            var B = int.Parse(this.TextBoxB.Text);
            var C = A + B;
            this.TextBoxC.Text = C.ToString();
        }
    }
}