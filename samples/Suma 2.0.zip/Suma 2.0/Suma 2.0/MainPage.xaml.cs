﻿using System;
using Xamarin.Forms;

namespace Suma_2._0
{
    /// <summary>
    /// Business Logic (BL): Suma 2.0
    /// </summary>
    public partial class MainPage : ContentPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        // Button Click Event Handler
        void OnButtonClicked(object sender, EventArgs args)
        {
            var A = int.Parse(this.boxA.Text);
            var B = int.Parse(this.boxB.Text);
            var C = A + B;
            boxAB.Text = C.ToString();
        }
    }
}
