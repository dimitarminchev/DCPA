﻿using System;
using Xamarin.Forms;

namespace Suma_2._0
{
    /// <summary>
    /// Suma 2.0
    /// </summary>
    public partial class MainPage : ContentPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        // Button Click Event Handler
        void OnButtonClicked(object sender, EventArgs args)
        {
            var A = int.Parse(EntryA.Text);
            var B = int.Parse(EntryB.Text);
            var C = A + B;
            EntryC.Text = C.ToString();
        }
    }
}
